# Scalable URL Shortener

A scalable, serverless URL shortener backend with:

- Rate limiting per IP (max 10 requests per hour)
- Expiration support with DynamoDB TTL
- Click count analytics
- Deployable on AWS Lambda + API Gateway
- Uses DynamoDB for storage

## Features

- Create a short URL from an original URL, optionally setting expiration time.
- Redirect short URLs to original URLs.
- Analytics endpoint to get total clicks and metadata.
- Rate limiting based on IP to prevent abuse.

## Tech Stack

- Node.js 18
- AWS Lambda
- API Gateway
- DynamoDB
- Serverless Framework

## Setup & Deployment

1. Install dependencies:

```bash
npm install
